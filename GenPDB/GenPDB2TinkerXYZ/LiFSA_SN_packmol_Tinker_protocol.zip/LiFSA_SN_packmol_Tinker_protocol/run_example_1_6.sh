#!/bin/bash
set -euo pipefail

# Example workflow for LiFSA/SN = 1/6, N_Li=N_FSA=142, N_SN=852.
# Requires packmol in PATH.

python3 scripts/make_packmol_lifsa_sn_table2.py setup \
  --fsa-xyz templates/FSA_final.xyz \
  --sn-xyz templates/SN_final.xyz \
  --outroot packmol_table2 \
  --systems 1_6_N142

cd packmol_table2/LiFSA_SN_1_6_N142
packmol < packmol.inp
cd ../..

python3 scripts/make_packmol_lifsa_sn_table2.py convert \
  --fsa-xyz templates/FSA_final.xyz \
  --sn-xyz templates/SN_final.xyz \
  --outroot packmol_table2 \
  --system 1_6_N142

python3 scripts/retag_lifsa_sn_xyz_to_LiFSAC2_prm.py \
  packmol_table2/LiFSA_SN_1_6_N142/LiFSA_SN_1_6_N142_Table2rho.xyz \
  packmol_table2/LiFSA_SN_1_6_N142/LiFSA_SN_1_6_N142_Table2rho_retyped.xyz

python3 scripts/check_tinker_xyz_overlaps.py \
  packmol_table2/LiFSA_SN_1_6_N142/LiFSA_SN_1_6_N142_Table2rho_retyped.xyz \
  --box 51.010376 \
  --cutoff 1.5 \
  --top 50

cp params/LiFSAC2_poltype2.prm packmol_table2/LiFSA_SN_1_6_N142/

echo "Done. Next: testgrad/minimize with Tinker using LiFSA_SN_1_6_N142_Table2rho_retyped.xyz"
