#!/usr/bin/env python3
"""
make_packmol_lifsa_sn_table2.py

Prepare Packmol inputs for Ugata et al. PCCP Table 2 LiFSA/SN liquid compositions
and convert Packmol PDB output back to Tinker xyz while preserving atom types and
connectivity from single-molecule Tinker xyz templates.

This script has two modes:

1) setup:
   Create template PDB files and Packmol input files.

   python3 make_packmol_lifsa_sn_table2.py setup \
     --fsa-xyz FSA_final.xyz \
     --sn-xyz SN_final.xyz \
     --outroot packmol_table2

2) convert:
   Convert a Packmol output PDB into Tinker xyz.

   python3 make_packmol_lifsa_sn_table2.py convert \
     --packmol-pdb packmol_table2/LiFSA_SN_1_6_N142/packmol_output.pdb \
     --fsa-xyz FSA_final.xyz \
     --sn-xyz SN_final.xyz \
     --n-li 142 --n-fsa 142 --n-sn 852 \
     --box 51.010376 \
     --output LiFSA_SN_1_6_N142_packmol_Table2rho.xyz

Recommended workflow:
   python3 make_packmol_lifsa_sn_table2.py setup --fsa-xyz FSA_final.xyz --sn-xyz SN_final.xyz
   cd packmol_table2/LiFSA_SN_1_6_N142
   packmol < packmol.inp
   cd ../..
   python3 make_packmol_lifsa_sn_table2.py convert --system 1_6_N142

By default, setup creates:
  - 1/6  : Li=142, FSA=142, SN=852, atoms=9940, L=51.010 Å
  - 1/10 : Li=90,  FSA=90,  SN=900, atoms=9900, L=50.880 Å

Both match the experimental density and LiFSA concentration in Table 2, up to
integer molecule-count rounding.
"""

from __future__ import annotations

import argparse
import math
import re
from dataclasses import dataclass
from pathlib import Path

NA = 6.02214076e23
M_LIFSA = 187.07
M_SN = 80.09

SYSTEMS = {
    "1_6_N142": {
        "dirname": "LiFSA_SN_1_6_N142",
        "ratio_sn": 6.0,
        "rho": 1.186,
        "n_li": 142,
        "tolerance": 2.2,
    },
    "1_10_N90": {
        "dirname": "LiFSA_SN_1_10_N90",
        "ratio_sn": 10.0,
        "rho": 1.121,
        "n_li": 90,
        "tolerance": 2.2,
    },
    "1_0p8_N191": {
        "dirname": "LiFSA_SN_1_0p8_N191",
        "ratio_sn": 0.8,
        "rho": 1.627,
        "n_li": 191,
        "tolerance": 2.2,
    },
}

@dataclass
class Atom:
    idx: int
    name: str
    x: float
    y: float
    z: float
    atype: int
    bonds: list[int]

def read_tinker_xyz(path: Path) -> list[Atom]:
    lines = path.read_text(errors="replace").splitlines()
    atoms = []
    for line in lines[1:]:
        p = line.split()
        if len(p) < 6:
            continue
        try:
            idx = int(p[0])
        except ValueError:
            continue
        atoms.append(Atom(
            idx=idx,
            name=p[1],
            x=float(p[2]),
            y=float(p[3]),
            z=float(p[4]),
            atype=int(p[5]),
            bonds=[int(v) for v in p[6:] if re.fullmatch(r"-?\d+", v)]
        ))
    return atoms

def elem(name: str) -> str:
    s = re.sub(r"[^A-Za-z]", "", name).upper()
    if s.startswith("LI"):
        return "Li"
    if s.startswith("CL"):
        return "Cl"
    if s.startswith("BR"):
        return "Br"
    return s[0].upper() if s else "X"

def center_atoms(atoms: list[Atom]) -> list[Atom]:
    cx = sum(a.x for a in atoms) / len(atoms)
    cy = sum(a.y for a in atoms) / len(atoms)
    cz = sum(a.z for a in atoms) / len(atoms)
    out = []
    for a in atoms:
        out.append(Atom(a.idx, a.name, a.x-cx, a.y-cy, a.z-cz, a.atype, list(a.bonds)))
    return out

def write_template_pdb(path: Path, atoms: list[Atom], resname: str):
    atoms = center_atoms(atoms)
    with path.open("w") as f:
        for i, a in enumerate(atoms, 1):
            e = elem(a.name)
            # PDB atom name width is awkward; Packmol only needs coordinates/order.
            f.write(
                f"HETATM{i:5d} {e:<4s} {resname:>3s} A   1"
                f"{a.x:12.3f}{a.y:8.3f}{a.z:8.3f}"
                f"  1.00  0.00          {e:>2s}\n"
            )
        f.write("END\n")

def write_li_pdb(path: Path):
    with path.open("w") as f:
        f.write("HETATM    1 Li   LI  A   1       0.000   0.000   0.000  1.00  0.00          Li\n")
        f.write("END\n")

def box_from_counts(n_li: int, n_sn: int, rho: float) -> float:
    mass_g = (n_li * M_LIFSA + n_sn * M_SN) / NA
    vol_a3 = mass_g / rho * 1.0e24
    return vol_a3 ** (1.0/3.0)

def cli_from_counts(n_li: int, box_a: float) -> float:
    vol_l = (box_a ** 3) * 1.0e-27
    mol = n_li / NA
    return mol / vol_l

def write_packmol_input(path: Path, n_li: int, n_fsa: int, n_sn: int, box: float, tol: float,
                        loose_factor: float = 1.0):
    L = box * loose_factor
    margin = 0.0
    with path.open("w") as f:
        f.write(f"""# Packmol input for LiFSA/SN liquid
# Target molecule counts: Li={n_li}, FSA={n_fsa}, SN={n_sn}
# Box length used here: L={L:.6f} Å
# If loose_factor=1, this is the Table 2 density box.
# If loose_factor>1, use NPT after minimization to compress back to Table 2 density.

tolerance {tol:.3f}
filetype pdb
output packmol_output.pdb
seed 12345
nloop 2000

structure ../templates/Li.pdb
  number {n_li}
  inside box {margin:.3f} {margin:.3f} {margin:.3f} {L:.6f} {L:.6f} {L:.6f}
end structure

structure ../templates/FSA.pdb
  number {n_fsa}
  inside box {margin:.3f} {margin:.3f} {margin:.3f} {L:.6f} {L:.6f} {L:.6f}
end structure

structure ../templates/SN.pdb
  number {n_sn}
  inside box {margin:.3f} {margin:.3f} {margin:.3f} {L:.6f} {L:.6f} {L:.6f}
end structure
""")

def parse_packmol_pdb_coords(path: Path) -> list[tuple[float,float,float]]:
    coords = []
    for line in path.read_text(errors="replace").splitlines():
        if line.startswith(("ATOM", "HETATM")):
            try:
                # Standard PDB columns; fallback to split if needed.
                x = float(line[30:38])
                y = float(line[38:46])
                z = float(line[46:54])
            except Exception:
                p = line.split()
                x, y, z = map(float, p[5:8])
            coords.append((x, y, z))
    return coords

def write_tinker_xyz_from_packmol(packmol_pdb: Path, output: Path,
                                  fsa_atoms: list[Atom], sn_atoms: list[Atom],
                                  n_li: int, n_fsa: int, n_sn: int,
                                  box: float, li_type: int = 6, li_name: str = "Li+"):
    coords = parse_packmol_pdb_coords(packmol_pdb)
    expected = n_li + n_fsa * len(fsa_atoms) + n_sn * len(sn_atoms)
    if len(coords) != expected:
        raise ValueError(f"Packmol PDB has {len(coords)} atoms, expected {expected}")

    out_lines = []
    out_lines.append(
        f"{expected:8d}  LiFSA/SN packmol; Li={n_li}, FSA={n_fsa}, SN={n_sn}; "
        f"L={box:.6f} A; cLi={cli_from_counts(n_li, box):.6f} M"
    )
    out_lines.append(f"{box:12.6f} {box:12.6f} {box:12.6f}   90.000000   90.000000   90.000000")

    idx = 1
    cpos = 0

    # The order must match packmol.inp: Li, then FSA, then SN.
    for _ in range(n_li):
        x, y, z = coords[cpos]
        cpos += 1
        out_lines.append(f"{idx:8d} {li_name:<4s} {x:14.6f} {y:14.6f} {z:14.6f} {li_type:6d}")
        idx += 1

    for _ in range(n_fsa):
        offset = idx - 1
        for tmpl in fsa_atoms:
            x, y, z = coords[cpos]
            cpos += 1
            bonds = " ".join(str(offset + b) for b in tmpl.bonds)
            line = f"{idx:8d} {tmpl.name:<4s} {x:14.6f} {y:14.6f} {z:14.6f} {tmpl.atype:6d}"
            if bonds:
                line += "  " + bonds
            out_lines.append(line)
            idx += 1

    for _ in range(n_sn):
        offset = idx - 1
        for tmpl in sn_atoms:
            x, y, z = coords[cpos]
            cpos += 1
            bonds = " ".join(str(offset + b) for b in tmpl.bonds)
            line = f"{idx:8d} {tmpl.name:<4s} {x:14.6f} {y:14.6f} {z:14.6f} {tmpl.atype:6d}"
            if bonds:
                line += "  " + bonds
            out_lines.append(line)
            idx += 1

    output.write_text("\n".join(out_lines) + "\n")
    print(f"Wrote {output}")
    print(f"atoms={expected}, L={box:.6f} A, cLi={cli_from_counts(n_li, box):.6f} M")

def setup(args):
    outroot = Path(args.outroot)
    templates = outroot / "templates"
    templates.mkdir(parents=True, exist_ok=True)

    fsa_atoms = read_tinker_xyz(Path(args.fsa_xyz))
    sn_atoms = read_tinker_xyz(Path(args.sn_xyz))

    write_li_pdb(templates / "Li.pdb")
    write_template_pdb(templates / "FSA.pdb", fsa_atoms, "FSA")
    write_template_pdb(templates / "SN.pdb", sn_atoms, "SN")

    for key in args.systems:
        s = SYSTEMS[key]
        n_li = int(s["n_li"])
        n_fsa = n_li
        n_sn = int(round(n_li * s["ratio_sn"]))
        L = box_from_counts(n_li, n_sn, s["rho"])
        cLi = cli_from_counts(n_li, L)

        d = outroot / s["dirname"]
        d.mkdir(parents=True, exist_ok=True)
        write_packmol_input(d / "packmol.inp", n_li, n_fsa, n_sn, L, s["tolerance"], args.loose_factor)

        info = f"""system = {key}
Li = {n_li}
FSA = {n_fsa}
SN = {n_sn}
atoms = {n_li + 9*n_fsa + 10*n_sn}
Table2_rho_g_cm3 = {s["rho"]}
box_Table2_A = {L:.6f}
box_packmol_A = {L * args.loose_factor:.6f}
cLi_M_at_Table2_box = {cLi:.6f}
packmol = packmol < packmol.inp
convert_Table2_box = python3 ../../make_packmol_lifsa_sn_table2.py convert --system {key}
convert_packmol_box = python3 ../../make_packmol_lifsa_sn_table2.py convert --system {key} --use-packmol-box
"""
        (d / "README.txt").write_text(info)
        print(info)

def convert(args):
    outroot = Path(args.outroot)
    if args.system:
        s = SYSTEMS[args.system]
        n_li = int(s["n_li"])
        n_fsa = n_li
        n_sn = int(round(n_li * s["ratio_sn"]))
        table_box = box_from_counts(n_li, n_sn, s["rho"])
        dirname = outroot / s["dirname"]
        packmol_pdb = dirname / "packmol_output.pdb"
        if args.use_packmol_box:
            # read from README
            packmol_inp = (dirname / "packmol.inp").read_text()
            m = re.search(r"inside box\s+\S+\s+\S+\s+\S+\s+([0-9.]+)\s+", packmol_inp)
            box = float(m.group(1)) if m else table_box
            tag = "packmolbox"
        else:
            box = table_box
            tag = "Table2rho"
        output = dirname / f"{s['dirname']}_{tag}.xyz"
    else:
        n_li, n_fsa, n_sn = args.n_li, args.n_fsa, args.n_sn
        box = args.box
        packmol_pdb = Path(args.packmol_pdb)
        output = Path(args.output)

    fsa_atoms = read_tinker_xyz(Path(args.fsa_xyz))
    sn_atoms = read_tinker_xyz(Path(args.sn_xyz))
    write_tinker_xyz_from_packmol(packmol_pdb, output, fsa_atoms, sn_atoms,
                                  n_li, n_fsa, n_sn, box, args.li_type, args.li_name)

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("setup")
    p.add_argument("--fsa-xyz", default="FSA_final.xyz")
    p.add_argument("--sn-xyz", default="SN_final.xyz")
    p.add_argument("--outroot", default="packmol_table2")
    p.add_argument("--systems", nargs="+", default=["1_6_N142", "1_10_N90"],
                   choices=sorted(SYSTEMS.keys()))
    p.add_argument("--loose-factor", type=float, default=1.0,
                   help=">1 makes initial box looser; convert with --use-packmol-box if keeping loose box")
    p.set_defaults(func=setup)

    p = sub.add_parser("convert")
    p.add_argument("--fsa-xyz", default="FSA_final.xyz")
    p.add_argument("--sn-xyz", default="SN_final.xyz")
    p.add_argument("--outroot", default="packmol_table2")
    p.add_argument("--system", choices=sorted(SYSTEMS.keys()), default=None)
    p.add_argument("--use-packmol-box", action="store_true",
                   help="Use the box length written in packmol.inp instead of Table 2 density box")
    p.add_argument("--packmol-pdb", default=None)
    p.add_argument("--output", default=None)
    p.add_argument("--n-li", type=int, default=None)
    p.add_argument("--n-fsa", type=int, default=None)
    p.add_argument("--n-sn", type=int, default=None)
    p.add_argument("--box", type=float, default=None)
    p.add_argument("--li-type", type=int, default=6)
    p.add_argument("--li-name", default="Li+")
    p.set_defaults(func=convert)

    args = ap.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
