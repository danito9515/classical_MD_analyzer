#!/usr/bin/env python3
"""
retag_lifsa_sn_xyz_to_LiFSAC2_prm.py

Retag atom types in a Tinker xyz file to match LiFSAC2_poltype2.prm.

Expected prm atom classes/types:
  Li+ : type 6
  FSA : O 81, S 164, F 91, N 72
  SN  : nitrile N 71, nitrile C 65, methylene C 66, H 13

The script identifies molecules from Tinker xyz connectivity:
  - Li+ : one isolated atom, element Li
  - FSA : 9-atom component containing S,S,N,O,O,O,O,F,F
  - SN  : 10-atom component containing N,N,C,C,C,C,H,H,H,H

It preserves coordinates and connectivity, only replacing atom types.
"""

from __future__ import annotations

import argparse
import re
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Atom:
    idx: int
    name: str
    x: float
    y: float
    z: float
    atype: int
    bonds: list[int]


def element(name: str) -> str:
    s = re.sub(r"[^A-Za-z]", "", name).upper()
    if s.startswith("LI"):
        return "Li"
    if s.startswith("CL"):
        return "Cl"
    if s.startswith("BR"):
        return "Br"
    return s[0].upper() if s else "X"


def read_tinker_xyz(path: Path):
    lines = path.read_text(errors="replace").splitlines()
    title = lines[0].rstrip()
    cell_line = None
    atoms = []
    for line in lines[1:]:
        p = line.split()
        if len(p) < 6:
            continue
        try:
            idx = int(p[0])
        except ValueError:
            cell_line = line.rstrip()
            continue
        atoms.append(Atom(
            idx=idx, name=p[1], x=float(p[2]), y=float(p[3]), z=float(p[4]),
            atype=int(p[5]), bonds=[int(v) for v in p[6:] if re.fullmatch(r"-?\d+", v)]
        ))
    return title, cell_line, atoms


def components(atoms):
    idx_set = {a.idx for a in atoms}
    adj = defaultdict(list)
    for a in atoms:
        for j in a.bonds:
            if j in idx_set:
                adj[a.idx].append(j)
                adj[j].append(a.idx)
    seen = set()
    comps = []
    for a in atoms:
        if a.idx in seen:
            continue
        q = deque([a.idx])
        seen.add(a.idx)
        comp = []
        while q:
            i = q.popleft()
            comp.append(i)
            for j in adj[i]:
                if j not in seen:
                    seen.add(j)
                    q.append(j)
        comps.append(sorted(comp))
    return comps


def retag(atoms):
    by_idx = {a.idx: a for a in atoms}
    comps = components(atoms)

    counts = Counter()
    changed = 0

    for comp in comps:
        comp_atoms = [by_idx[i] for i in comp]
        elems = Counter(element(a.name) for a in comp_atoms)

        # Li+
        if len(comp_atoms) == 1 and elems == Counter({"Li": 1}):
            a = comp_atoms[0]
            if a.atype != 6:
                changed += 1
            a.atype = 6
            a.name = "Li+"
            counts["Li"] += 1
            continue

        # FSA: S2 N1 O4 F2
        if len(comp_atoms) == 9 and elems == Counter({"S": 2, "N": 1, "O": 4, "F": 2}):
            for a in comp_atoms:
                e = element(a.name)
                newtype = {"S": 164, "N": 72, "O": 81, "F": 91}[e]
                if a.atype != newtype:
                    changed += 1
                a.atype = newtype
            counts["FSA"] += 1
            continue

        # SN: C4 H4 N2
        if len(comp_atoms) == 10 and elems == Counter({"C": 4, "H": 4, "N": 2}):
            comp_set = set(comp)
            for a in comp_atoms:
                e = element(a.name)
                if e == "H":
                    newtype = 13
                elif e == "N":
                    newtype = 71
                elif e == "C":
                    # Nitrile carbon has an N neighbor; methylene carbon does not.
                    neigh_elems = [element(by_idx[j].name) for j in a.bonds if j in comp_set]
                    if "N" in neigh_elems:
                        newtype = 65
                    else:
                        newtype = 66
                else:
                    raise RuntimeError(f"Unexpected SN element {e} at atom {a.idx}")
                if a.atype != newtype:
                    changed += 1
                a.atype = newtype
            counts["SN"] += 1
            continue

        raise RuntimeError(
            f"Unknown component: size={len(comp_atoms)}, elems={dict(elems)}, "
            f"atom_indices={comp[:20]}"
        )

    return counts, changed


def write_tinker_xyz(path: Path, title: str, cell_line: str | None, atoms):
    with path.open("w") as f:
        f.write(title + " ; atom types retagged for LiFSAC2_poltype2.prm\n")
        if cell_line:
            f.write(cell_line + "\n")
        for a in sorted(atoms, key=lambda x: x.idx):
            bonds = " ".join(str(j) for j in a.bonds)
            f.write(f"{a.idx:8d} {a.name:<4s} {a.x:14.6f} {a.y:14.6f} {a.z:14.6f} {a.atype:6d}")
            if bonds:
                f.write("  " + bonds)
            f.write("\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()

    title, cell_line, atoms = read_tinker_xyz(args.input)
    counts, changed = retag(atoms)
    write_tinker_xyz(args.output, title, cell_line, atoms)

    print(f"Wrote: {args.output}")
    print(f"Counts: Li={counts['Li']}, FSA={counts['FSA']}, SN={counts['SN']}")
    print(f"Changed atom types: {changed}")


if __name__ == "__main__":
    main()
