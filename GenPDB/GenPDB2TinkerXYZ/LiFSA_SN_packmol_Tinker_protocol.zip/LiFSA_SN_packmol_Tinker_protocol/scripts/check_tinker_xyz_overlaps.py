#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
import re
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path

@dataclass
class Atom:
    idx: int
    name: str
    x: float
    y: float
    z: float
    atype: int
    bonds: list[int]

def elem_from_name(name: str) -> str:
    s = re.sub(r"[^A-Za-z]", "", name).upper()
    if s.startswith("LI"):
        return "Li"
    if s.startswith("CL"):
        return "Cl"
    if s.startswith("BR"):
        return "Br"
    return s[0].upper() if s else "X"

def read_tinker_xyz(path: Path):
    lines = path.read_text(errors="replace").splitlines()
    n = int(lines[0].split()[0])
    atoms = []
    for line in lines[1:]:
        parts = line.split()
        if len(parts) < 6:
            continue
        try:
            idx = int(parts[0])
            name = parts[1]
            x, y, z = map(float, parts[2:5])
            atype = int(parts[5])
            bonds = [int(v) for v in parts[6:] if re.fullmatch(r"-?\d+", v)]
        except Exception:
            continue
        atoms.append(Atom(idx, name, x, y, z, atype, bonds))
    if len(atoms) != n:
        print(f"WARNING: header atom count {n}, parsed {len(atoms)}")
    return lines[0], atoms

def min_image(dx, box):
    if box is None:
        return dx
    return dx - box * round(dx / box)

def distance(a, b, box):
    dx = min_image(a.x - b.x, box)
    dy = min_image(a.y - b.y, box)
    dz = min_image(a.z - b.z, box)
    return math.sqrt(dx*dx + dy*dy + dz*dz)

def components(atoms):
    idx_set = {a.idx for a in atoms}
    adj = defaultdict(list)
    for a in atoms:
        for j in a.bonds:
            if j in idx_set:
                adj[a.idx].append(j)
                adj[j].append(a.idx)
    comp = {}
    cid = 0
    for a in atoms:
        if a.idx in comp:
            continue
        cid += 1
        q = deque([a.idx])
        comp[a.idx] = cid
        while q:
            i = q.popleft()
            for j in adj[i]:
                if j not in comp:
                    comp[j] = cid
                    q.append(j)
    return comp

def main():
    ap = argparse.ArgumentParser(description="Detect short nonbonded contacts in Tinker xyz.")
    ap.add_argument("xyz", type=Path)
    ap.add_argument("--box", type=float, default=None, help="cubic box length in Angstrom")
    ap.add_argument("--cutoff", type=float, default=1.50)
    ap.add_argument("--top", type=int, default=100)
    ap.add_argument("--include-same-molecule", action="store_true")
    ap.add_argument("--include-bonded", action="store_true")
    args = ap.parse_args()

    title, atoms = read_tinker_xyz(args.xyz)
    comp = components(atoms)
    bonded = set()
    for a in atoms:
        for j in a.bonds:
            bonded.add(tuple(sorted((a.idx, j))))

    hits = []
    for ii, a in enumerate(atoms):
        for b in atoms[ii+1:]:
            pair = tuple(sorted((a.idx, b.idx)))
            if not args.include_bonded and pair in bonded:
                continue
            same = comp.get(a.idx) == comp.get(b.idx)
            if same and not args.include_same_molecule:
                continue
            r = distance(a, b, args.box)
            if r < args.cutoff:
                hits.append((r, a, b, same))

    hits.sort(key=lambda x: x[0])
    by_elem = defaultdict(int)
    by_comp = defaultdict(int)
    for r, a, b, same in hits:
        key = "-".join(sorted((elem_from_name(a.name), elem_from_name(b.name))))
        by_elem[key] += 1
        by_comp[(comp.get(a.idx), comp.get(b.idx))] += 1

    print(f"File: {args.xyz}")
    print(f"Title: {title}")
    print(f"Atoms: {len(atoms)}")
    print(f"Box: {args.box if args.box else 'None'} Angstrom")
    print(f"Cutoff: {args.cutoff:.3f} Angstrom")
    print(f"Suspicious contacts: {len(hits)}")
    print("\nCounts by element pair:")
    for k, v in sorted(by_elem.items(), key=lambda kv: (-kv[1], kv[0])):
        print(f"  {k:8s} {v}")
    print(f"\nTop {min(args.top, len(hits))} shortest contacts:")
    print(" rank   r/A    atom_i name_i type_i mol_i   atom_j name_j type_j mol_j same")
    for rank, (r, a, b, same) in enumerate(hits[:args.top], 1):
        print(f"{rank:5d} {r:7.3f} {a.idx:8d} {a.name:6s} {a.atype:6d} {comp.get(a.idx):6d} "
              f"{b.idx:8d} {b.name:6s} {b.atype:6d} {comp.get(b.idx):6d} {same}")
    if hits:
        print("\nWorst molecule/component pairs:")
        for (ci, cj), v in sorted(by_comp.items(), key=lambda kv: -kv[1])[:20]:
            print(f"  mol {ci} - mol {cj}: {v} contacts")

if __name__ == "__main__":
    main()
